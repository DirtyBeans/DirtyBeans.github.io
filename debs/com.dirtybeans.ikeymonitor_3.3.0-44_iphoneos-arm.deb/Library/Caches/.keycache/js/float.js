// JavaScript Document

$(document).ready(function() {  
	if (!( navigator.userAgent.match(/(iPad|iPhone|iPod);.*CPU.*OS 4_\d/i))&& !(navigator.userAgent.match(/(iPad|iPhone|iPod);.*CPU.*OS 3_\d/i) ) ) {
		
		
		
		document.getElementById('header').style.position='fixed'
		document.getElementById('footer').style.position='fixed'	
		 $("input[type='text'],input[type='number'],input[type='Password']").bind({  
        focusin:function (){  
				//$(this).focus() ;
				scrollTop =document.body.scrollTop;
				if(scrollTop<375){
				    window.scrollTo(0,scrollTop+70)
				}else{
					window.scrollTo(0,scrollTop-20)
				}
				window.onresize = window.onscroll = function () {
					
					if(Math.max(document.body.scrollTop,document.documentElement.scrollTop )==0||reachBottom()){
										document.getElementById('header').style.position='relative'
										document.getElementById('footer').style.position='relative'
										document.getElementById('header').style.display=''
										document.getElementById('footer').style.display=''
						
						
					}else{
						
						document.getElementById('header').style.display='none'
						document.getElementById('footer').style.display='none'
						
					}
					
					
				}



            },  
        focusout:function (){  
				document.getElementById('header').style.display=''
				document.getElementById('footer').style.display=''
				document.getElementById('header').style.position='fixed'
				document.getElementById('footer').style.position='fixed'
			window.onresize = window.onscroll = function () {
				document.getElementById('header').style.display=''
				document.getElementById('footer').style.display=''
				document.getElementById('header').style.position='fixed'
				document.getElementById('footer').style.position='fixed'
			}

        }  
     });  
	}
});




if (( navigator.userAgent.match(/(iPad|iPhone|iPod);.*CPU.*OS 4_\d/i))|| (navigator.userAgent.match(/(iPad|iPhone|iPod);.*CPU.*OS 3_\d/i) ) ) {
	window.addEventListener("load", function () { 
	setTimeout(function () { 
	 var footer = document.getElementById('footer');
	  var header = document.getElementById('header');
	  window.scrollTo(0, 1);   	
		var lowerleft = [window.pageXOffset,(window.pageYOffset+window.innerHeight)];
		var lowerright = [(lowerleft[0] + window.innerWidth),lowerleft[1]];
		var zoomFactor = window.innerWidth/document.documentElement.clientWidth;
	
		footer.style.width = lowerright[0] - lowerleft[0] + 'px';
		footer.style.height = footer.clientHeight + 'px';
		footer.style.left = lowerleft[0] + 'px';
		footer.style.top = lowerleft[1]-el.offsetHeight + 'px';
		footer.style.fontSize = parseInt(zoomFactor*60) + 'px';
		
	
		
		
		}, 100); 
	});	
	var el;
	var hd;	
	window.onresize = window.onscroll = function () {
		var lowerleft = [window.pageXOffset,(window.pageYOffset+window.innerHeight)];
		var lowerright = [(lowerleft[0] + window.innerWidth),lowerleft[1]];
		var zoomFactor = window.innerWidth/document.documentElement.clientWidth;
	
		el.style.width = lowerright[0] - lowerleft[0] + 'px';
		el.style.height = el.clientHeight + 'px';
		el.style.left = lowerleft[0] + 'px';
		el.style.top = lowerleft[1]-el.offsetHeight + 'px';
		el.style.fontSize = parseInt(zoomFactor*60) + 'px';
	
	
		hd.style.width = lowerright[0] - lowerleft[0] + 'px';
		hd.style.height = hd.clientHeight + 'px';
		hd.style.left = lowerleft[0] + 'px';
		hd.style.top = 0+Math.max(document.body.scrollTop,document.documentElement.scrollTop ) + 'px';
		hd.style.fontSize = parseInt(zoomFactor*60) + 'px';
	
	
	}
	
	window.onload = function () {
		el = document.getElementById('footer');
		hd =document.getElementById('header');
	
	//	fontAdjustment = 60/document.documentElement.clientWidth;
		window.onresize();
	}
}else{
	setTimeout(function() { window.scrollTo(0, 1) }, 100);
	window.addEventListener("load", hideAddressBar );window.addEventListener("orientationchange", hideAddressBar );	
}


			


function reachBottom() {

    var scrollTop = 0;

    var clientHeight = 0;

    var scrollHeight = 0;

    if (document.documentElement && document.documentElement.scrollTop) {

        scrollTop = document.documentElement.scrollTop;

    } else if (document.body) {

        scrollTop = document.body.scrollTop;

    }

    if (document.body.clientHeight && document.documentElement.clientHeight) {

        clientHeight = (document.body.clientHeight < document.documentElement.clientHeight) ? document.body.clientHeight: document.documentElement.clientHeight;

    } else {

        clientHeight = (document.body.clientHeight > document.documentElement.clientHeight) ? document.body.clientHeight: document.documentElement.clientHeight;

    }

    scrollHeight = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);

    if (scrollTop + clientHeight =='1462'||scrollTop + clientHeight == '1830'||scrollTop + clientHeight == '1553'||scrollTop + clientHeight == '1689') {
        return true;

    } else {

        return false;

    }

}


